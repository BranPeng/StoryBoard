//
//  KJPHAsset.m
//  Join
//
//  Created by JOIN iOS on 2017/8/29.
//  Copyright © 2017年 huangkejin. All rights reserved.
//

#import "KJPHAsset.h"

@implementation KJPHAsset

@end
