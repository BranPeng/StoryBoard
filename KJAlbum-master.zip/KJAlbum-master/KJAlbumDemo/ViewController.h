//
//  ViewController.h
//  KJAlbumDemo
//
//  Created by JOIN iOS on 2017/9/5.
//  Copyright © 2017年 Kegem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

